import * as React from 'react';
import { ChartContainer } from '@mui/x-charts'; // Importing ChartContainer component from MUI X-Charts
import { LinePlot, MarkPlot } from '@mui/x-charts/LineChart'; // Importing LinePlot and MarkPlot components from MUI X-Charts

const pData = [2400, 1398, 9800, 3908, 4800, 3800, 4300]; // Sample data for the chart
const xLabels = [ // Labels for the x-axis
  'Page A',
  'Page B',
  'Page C',
  'Page D',
  'Page E',
  'Page F',
  'Page G',
];

// Functional component for the TinyLineChart
export default function TinyLineChart(colour) {
    const chartColour = colour.colour; // Extracting the colour from the prop
    console.log(chartColour); // Logging the extracted colour
  return (
    // ChartContainer for the TinyLineChart
    <ChartContainer
      width={200} // Width of the chart
      height={150} // Height of the chart
      series={[{ type: 'line', data: pData }]} // Series data for the chart
      xAxis={[{ scaleType: 'point', data: xLabels }]} // X-axis configuration
      sx={{ // Custom styles for the chart elements
        '.MuiLineElement-root': {
          stroke: `${chartColour}`, // Colour for the line plot
          strokeWidth: 0.5, // Stroke width for the line plot
        },
        '.MuiMarkElement-root': {
          stroke: `${chartColour}`, // Colour for the mark plot
          scale: '0.1', // Scale for the mark plot
          fill: '#fff', // Fill colour for the mark plot
          strokeWidth: 0.5, // Stroke width for the mark plot
        },
      }}
      disableAxisListener // Disabling axis listener
    >
      <LinePlot /> {/* Rendering the LinePlot component */}
      <MarkPlot /> {/* Rendering the MarkPlot component */}
    </ChartContainer>
  );
}
