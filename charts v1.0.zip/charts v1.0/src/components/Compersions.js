// Importing necessary modules and stylesheets
import * as React from 'react';
import { BarChart } from '@mui/x-charts/BarChart'; // Importing BarChart component from MUI X-Charts
import countryComparison from '../data/countryComparison.json'; // Importing JSON data
import "../stylesheets/Comparisons.css"; // Importing CSS stylesheet

// Configuration for the BarChart component
const chartSetting = {
  xAxis: [{}], // Empty xAxis object for now
  width: 600, // Width of the chart
  height: 400, // Height of the chart
};

// Function to format values displayed on the chart
const valueFormatter = (value) => `${value}%`;

// Functional component to display Horizontal Bar Chart
export default function HorizontalBars() {
  return (
    <div className='comperisonsContent'> {/* Container div for the chart */}
      <BarChart
        dataset={countryComparison} // Dataset for the chart
        yAxis={[{ scaleType: 'band', dataKey: "label" }]} // Configuration for yAxis
        series={[{ dataKey: 'value',  valueFormatter }]} // Configuration for series
        layout="horizontal" // Layout of the chart (horizontal)
        margin={{ left: 100, right: 10 }} // Margin for the chart
        {...chartSetting} // Spread operator to pass chartSetting configurations
      />
    </div>
  );
}
