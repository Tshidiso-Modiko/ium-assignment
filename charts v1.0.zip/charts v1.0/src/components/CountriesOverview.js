import React from 'react';
import '../stylesheets/Overview.css'; // Importing CSS stylesheet
import Button from '@mui/material/Button'; // Importing Button component from MUI
import { styled } from '@mui/material/styles'; // Importing styled function from MUI
import TinyLineChart from './tineyChart'; // Importing TinyLineChart component
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp'; // Importing ArrowDropUpIcon component from MUI
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown'; // Importing ArrowDropDownIcon component from MUI

// Sample data for demonstration
const pData = [2400, 1398, 9800, 3908, 4800, 3800, 4300];
const xLabels = [
  'Page A',
  'Page B',
  'Page C',
  'Page D',
  'Page E',
  'Page F',
  'Page G',
];

// Functional component to display overview of countries
const CountriesOverview = () => {

    // Styling the Button component using styled function from MUI
    const ColorButton = styled(Button)(({ theme }) => ({
        color: '#FFFFFF',
        backgroundColor: '#02E38D',
        borderColor: '#02E38D',
        
        '&:hover': {
          backgroundColor: '#FFFFFF',
          borderColor: '#02E38D',
          color: '#02E38D',
        },
    }));
      
    return (
        <div>
            <table className='overviewTable'> {/* Container for the overview table */}
                <tbody>
                    <tr>
                        <td>
                            <a>Italy</a> {/* Link to Italy */}
                            <h1>R5900.00<ArrowDropUpIcon style={{ color: '#00D100' }}/></h1> {/* Displaying price with ArrowDropUpIcon */}
                            <TinyLineChart colour ={'#00D100'}/> {/* Displaying TinyLineChart with green color */}
                        </td>
                        <td>
                            <a>United States</a>
                            <h1>R950.00<ArrowDropUpIcon style={{ color: '#00D100' }}/></h1>
                            <TinyLineChart colour ={'#00D100'}/>
                        </td>
                        <td>
                            <a>Canada</a>
                            <h1>R450.00<ArrowDropDownIcon style={{ color: 'red' }}/></h1>
                            <TinyLineChart colour ={'#FF0000'}/>
                        </td>
                        <td>
                            <a>Spain</a>
                            <h1>R450.00<ArrowDropUpIcon style={{ color: '#00D100' }}/></h1>
                            <TinyLineChart colour ={'#00D100'}/>
                        </td>
                        <td>
                            <a>Japan</a>
                            <h1>R450.00<ArrowDropUpIcon style={{ color: '#00D100' }}/></h1>
                            <TinyLineChart colour ={'#00D100'}/>
                        </td>
                        <td>
                            <a>South Africa</a>
                            <h1>R450.00<ArrowDropDownIcon style={{ color: 'red' }}/></h1>
                            <TinyLineChart colour ={'#FF0000'}/>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
};

export default CountriesOverview;

