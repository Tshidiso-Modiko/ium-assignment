import '../stylesheets/App.css'; // Importing external CSS file for styling
import React from 'react'; // Importing React library
import Navbar from "./Navbar"; // Importing Navbar component
import Team from "./TeamMembers"; // Importing TeamMembers component
import ChartComperison from "./Compersions"; // Importing Compersions component
import Header from "./Header"; // Importing Header component
import Numbers from './Numbers'; // Importing Numbers component
import CountriesOverview from './CountriesOverview'; // Importing CountriesOverview component

function App() {
  return (
    <div className="App"> {/* Main container */}
      <div className='viewContainer'> {/* Container for left and right panels */}
        <div className="leftPanel"> {/* Left panel containing Navbar */}
          <Navbar/> {/* Render Navbar component */}
        </div>
        <div className="rightPanel"> {/* Right panel containing data */}
          <table> {/* Container for data cards */}
            <tr> {/* Row for revenue header */}
              <th colspan="2"> {/* Header for revenue section */}
                <div className="dataCard revenueCard"> {/* Container for revenue data */}
                  <Header/> {/* Render Header component */}
                </div>
              </th>
            </tr>
            <tr> {/* Row for numbers section */}
              <th colspan="2"> {/* Header for numbers section */}
                <div className="dataCard revenueCard"> {/* Container for numbers data */}
                  <Numbers/> {/* Render Numbers component */}
                </div>
              </th>
            </tr>
            <tr> {/* Row for countries overview section */}
              <th colspan="2"> {/* Header for countries overview section */}
                <div className="dataCard revenueCard"> {/* Container for countries overview data */}
                  <CountriesOverview/> {/* Render CountriesOverview component */}
                </div>
              </th>
            </tr>
            <tr> {/* Row for team members and comparison */}
              <th> {/* Column for team members */}
                <div className= "teamTitle"> {/* Container for team members title */}
                  <h3 className="catTitle">Team Members</h3> {/* Team members title */}
                </div>
              </th>
              <th> {/* Column for comparison */}
                  <div className= "countryCompTitle"> {/* Container for comparison title */}
                    <h3 className="catTitle">Comparison</h3>  {/* Comparison title */}
                  </div>
              </th>
            </tr>
            <tr style={{maxHeight:"500px"}}> {/* Row for team members and comparison data */}
             <td colSpan={1}> {/* Column for team members */}
                <div className= "Team"> {/* Container for team members data */}
                  <Team/> {/* Render TeamMembers component */}
                </div>      
              </td>
              <td colSpan={1}> {/* Column for comparison */}
                <div className= "dataCard countryComparison"> {/* Container for comparison data */}
                    <ChartComperison/> {/* Render Compersions component */}
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  );
}

export default App; // Exporting App component

