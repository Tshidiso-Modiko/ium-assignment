import React from 'react';
import '../stylesheets/Header.css'; // Importing CSS stylesheet
import teamJson from '../data/teamMembers.json'; // Importing JSON data for team members
import Avatar from '@mui/material/Avatar'; // Importing Avatar component from MUI
import Button from '@mui/material/Button'; // Importing Button component from MUI
import AddIcon from '@mui/icons-material/Add'; // Importing AddIcon component from MUI
import { styled } from '@mui/material/styles'; // Importing styled function from MUI

// Functional component for the header section
const Header = () => {
    // Styling the Button component using styled function from MUI
    const ColorButton = styled(Button)(({ theme }) => ({
        color: '#FFFFFF',
        backgroundColor: '#02E38D',
        borderColor: '#02E38D',
        
        '&:hover': {
          backgroundColor: '#FFFFFF',
          borderColor: '#02E38D',
          color: '#02E38D',
        },
    }));
      
    return (
        <div>
            <table className='headerTable'> {/* Container for the header */}
                <tbody>
                    <tr>
                        <td>
                            <h1>Dashboard</h1> {/* Title for the dashboard */}
                            <a>{`Welcome back, ${teamJson[0].first_name}`}</a> {/* Welcome message with the first name of the team member */}
                        </td>
                        <td>      
                            <ColorButton variant="outlined" startIcon={<AddIcon/>} size="small" color="success">Add Unit</ColorButton> {/* Button to add unit */}
                        </td>
                        <td>
                            <div className="User"> {/* Container for user information */}
                                <div className="userInfo">
                                    <Avatar
                                    alt="Remy Sharp"
                                    src={teamJson[0].picture} // Avatar image of the first team member
                                    sx={{ width: 45, height: 45}} // Styling for the Avatar component
                                    />
                                    <div className='userName'>{teamJson[0].first_name} {teamJson[0].last_name}</div> {/* Full name of the first team member */}
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
};

export default Header; // Exporting the Header component
