import React from 'react';
import '../stylesheets/Numbers.css'; // Import CSS file for styling
import teamJson from '../data/teamMembers.json'; // Import JSON data for team members
import Avatar from '@mui/material/Avatar'; // Import Avatar component from MUI
import Button from '@mui/material/Button'; // Import Button component from MUI
import AddIcon from '@mui/icons-material/Add'; // Import AddIcon component from MUI
import AvatarGroup from '@mui/material/AvatarGroup'; // Import AvatarGroup component from MUI
import Rand from '../media/Rand.jpeg'; // Import Rand image
import Dollar from '../media/Dollar.jpeg'; // Import Dollar image
import Euro from '../media/Euro.jpeg'; // Import Euro image
import Yen from '../media/Yen.jpeg'; // Import Yen image
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp'; // Import ArrowDropUpIcon component from MUI
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown'; // Import ArrowDropDownIcon component from MUI

import { styled } from '@mui/material/styles'; // Import styled function from MUI

const Numbers = () => { // Functional component for displaying numbers

    return (
        <div>
            <table className='numbersTable'> {/* Container for the numbers table */}
                <tbody>
                    <tr>
                        <td>
                            <a>BALANCE</a> {/* Title for balance */}
                            <h1>R5900.00</h1> {/* Balance amount */}
                        </td>
                        <td>
                            <a>PROFITS</a> {/* Title for profits */}
                            <h1>R950.00<ArrowDropUpIcon style={{ color: '#00D100' }}/></h1> {/* Profits amount with ArrowDropUpIcon */}
                        </td>
                        <td>
                            <a>LOSSES</a> {/* Title for losses */}
                            <h1>R450.00<ArrowDropDownIcon style={{ color: 'red' }}/></h1> {/* Losses amount with ArrowDropDownIcon */}
                        </td>
                        <td style={{paddingTop: "0.5em"}}> {/* Container for currencies */}
                            <div className='Currencies'>
                                <a>CURRENCIES</a> {/* Title for currencies */}
                                {/* AvatarGroup to display currency avatars */}
                                <AvatarGroup max={4} sx={{paddingTop: 2}}>
                                    <Avatar alt="Remy Sharp" src={Rand} /> {/* Rand avatar */}
                                    <Avatar alt="Travis Howard" src={Dollar} /> {/* Dollar avatar */}
                                    <Avatar alt="Cindy Baker" src={Euro}/> {/* Euro avatar */}
                                    <Avatar alt="Agnes Walker" src={Yen} /> {/* Yen avatar */}
                                </AvatarGroup>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
};

export default Numbers; // Exporting the Numbers component
