import React, { useState, useEffect } from 'react';
import teamJson from '../data/teamMembers.json'; // Importing JSON data for team members
import "../stylesheets/Team.css"; // Importing CSS file for styling
import Avatar from '@mui/material/Avatar'; // Importing Avatar component from MUI
import Stack from '@mui/material/Stack'; // Importing Stack component from MUI
import Chip from '@mui/material/Chip'; // Importing Chip component from MUI

// Functional component to display team members
const TeamMembers = () => {

    return (
        <div className="teamContent"> {/* Container for the team content */}
            <div className="teamList"> {/* Container for the team list */}
                {/* Mapping through the teamJson array to render team members */}
                {teamJson.map((member, index) => (
                    <li key={member.first_name} className={`teamItem`} style={{ animationDelay: `${index * 0.1}s` }}> {/* List item for each team member */}
                        <div className="teamMember"> {/* Container for each team member */}
                            <div className="memberInfo"> {/* Container for member information */}
                                <Avatar
                                alt={member.first_name} // Alt text for the Avatar
                                src={member.picture} // Source of the Avatar image
                                sx={{ width: 24, height: 24 }} // Styling for the Avatar
                                />
                            <span className="name">{member.first_name} {member.last_name}</span> {/* Displaying member's full name */}
                            </div>
                            <div className="role"><Chip label={member.role}  size="small" color={member.chip_colour} variant="outlined"/></div> {/* Displaying member's role with a Chip */}
                        </div>
                    </li>
                ))}
            </div>
        </div>
    )
}
export default TeamMembers; // Exporting the TeamMembers component
