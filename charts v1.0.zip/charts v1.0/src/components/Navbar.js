import React, { useState } from 'react';
import '../stylesheets/Navbar.css'; // Import CSS file for styling
import SpeedIcon from '@mui/icons-material/Speed';
import BarChartIcon from '@mui/icons-material/BarChart';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import LogoutIcon from '@mui/icons-material/Logout';
import { ListItem, ListItemIcon, ListItemText } from '@mui/material';

// Functional component for the vertical navbar
const VerticalNavbar = () => {
    // State variables
    const [profileComponent, setProfileComponent] = useState({ class: "" });
    const [logoutClicked, setLogoutClicked] = useState(false);
    const [loginComponent, setLoginComponent] = useState({ class: "" });

    // Function to handle click events on list items
    function changeLiState(event) {
        event.preventDefault();
        console.log(event.target)
        console.log(event.target.id)
        switch (event.target.id) {
            case "logoutLinkClick":
                console.log("Login clicked")
                setLoginComponent(
                    { class: "active" }
                )
                break;
            default:
                break;
        }
    }

    return (
        <div className="verticalNavbar"> {/* Container for the vertical navbar */}
            {/* List items for various options */}
            <li>
                <div className='iconContainer'>
                    <a href="#">
                        <ListItemIcon sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '8px' }}>
                            <SpeedIcon fontSize="large" />
                        </ListItemIcon>
                        Dashboard
                    </a>
                </div>
            </li>
            {/* Similar blocks for other list items */}
            {/* ............ */}
            <li>
                <div className='iconContainer'>
                    <a href="#">
                        <ListItemIcon sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '8px'}}>
                            <BarChartIcon fontSize="large"/>
                        </ListItemIcon>
                        Analytics
                    </a>
                </div>
            </li>
            <li>
                <div className='iconContainer'>
                    <a href="#">
                        <ListItemIcon sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '8px' }}>
                            <AutorenewIcon fontSize="large"/>
                        </ListItemIcon>
                        Trading
                    </a>
                </div>
            </li>
            <li>
                <div className='iconContainer'>
                    <a href="#">
                        <ListItemIcon sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '8px' }}>
                            <NotificationsNoneIcon fontSize="large"/>
                        </ListItemIcon>
                        Notifications
                    </a>
                </div>
            </li>
            <div className="logoutContainer"> {/* Container for logout */}
                <li>
                    <div className='iconContainer'>
                        <a id="logoutLinkClick" className={loginComponent.class} onClick={changeLiState}>
                            <ListItemIcon sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '8px' }}>
                                <LogoutIcon fontSize="large" />
                            </ListItemIcon>
                            Logout
                        </a>
                    </div>
                </li>
            </div>
        </div>
    );
};

export default VerticalNavbar; // Exporting the VerticalNavbar component
